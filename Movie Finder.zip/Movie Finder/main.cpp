

#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>

using namespace std;

const int MOVIES_SIZE = 20;


// Declare a struct named Movie with 3 members for:
// title, year released, and revenue
    struct Movie
    {
        string title;
        int yearReleased;
        long long revenue;
    };


// Enter here your function prototypes
void storeMoviesArray(ifstream &inFile, Movie topMovies[], const int SIZE);
void sortMoviesTitle(Movie topMovies[], const int SIZE);
void printMoviesArray(const Movie topMovies[], const int SIZE);
int  findMovieTitle(const Movie topMovies[], const int SIZE, const string &title);

// main() starts here
int main()
{
	// Declare file variable
    ifstream inFile;
	// Open file Movies.txt
    inFile.open("Movies.txt");
	// Check if file was opened
    if(!inFile)
    {
        cout << "Error, unable to read file" << endl;
        return 1;
    }
	// Declare array of movies
    Movie topMovies[MOVIES_SIZE];
	// Declare auxiliary variables
    string title;
    int index;
    char answer;    
	// Read the information from the movies file and store it in the array
    storeMoviesArray(inFile, topMovies, MOVIES_SIZE);
	// Sort the array by the movie title so the binary search can be used 
    sortMoviesTitle(topMovies, MOVIES_SIZE);
	// Start the loop
    do
    {
		// Clear the screen
	    system("clear");
		// Print the movies array
        printMoviesArray(topMovies, MOVIES_SIZE);
		// Ask the user to input a title
        cout << "Enter a movie title: ";
        cin.ignore(1000, '\n');   
        getline(cin, title);
		// Find the index of the movie that the user chooses
        index = findMovieTitle(topMovies, MOVIES_SIZE, title);
		// If the movie was not found
		//		Print the message indicating the title was not found
		if (index == -1)
		    {
		        cout << "Title: " << title << " was not found. " << endl;
		    }
		// Otherwise
		//		Print the information about the chosen movie
        else
        {
            cout << "Title: " << topMovies[index].title << endl;
            cout << "Year Released: " << topMovies[index].yearReleased << endl;
            cout << "Revenue: " << topMovies[index].revenue << endl << endl;
        }
		// Ask the user "Do you want to continue? (y/n): "
        cout << "Do you want to continue? (y/n): ";
		// Get the answer
        cin >> answer;
	// Continue looping while the answer is 'y'
    } while (answer == 'y' || answer == 'Y');
	// Close the file
    inFile.close();
// main() ends here
    return 0;
}

// Function definitions start here

void storeMoviesArray(ifstream &inFile, Movie topMovies[], const int SIZE)
// This function receives the input file, the movies array, and the size of the 
// array. 
// It reads from the file the movie data and stores it in the array.
// Once all the data has been read in, it returns the array with the information 
// of the movies.
{
    for (int i = 0; i < SIZE; ++i)
    {
        inFile >> topMovies[i].title;
        inFile >> topMovies[i].yearReleased;
        inFile >> topMovies[i].revenue;
    }
}

void sortMoviesTitle(Movie topMovies[], const int SIZE)
// This function receives the movies array and the size of the array and sorts
// the array by title. It returns the sorted array.
{
    Movie temp;

    for (int i = 0; i < SIZE; ++i)
    {
        for (int j = 0; j < SIZE - i - 1; ++j)
        {
            if (topMovies[j].title > topMovies[j + 1].title)
            {
                temp = topMovies[j];
                topMovies[j] = topMovies[j + 1];
                topMovies[j + 1] = temp;
            }
        }
    }
}

void printMoviesArray(const Movie topMovies[], const int SIZE)
// This function receives the movies array and the size of the array and prints
// the list of movies.
{
    // Header (roughly centered like the reference)
    cout << "                   Movie title          Year             Revenue" << endl << endl;

    for (int i = 0; i < SIZE; ++i)
    {
        cout << setw(32) << topMovies[i].title; // title column
        cout << " " << setw(11) << right << topMovies[i].yearReleased;    // year
        cout << " " << setw(11) << right << "$ " << topMovies[i].revenue; // revenue
        cout << endl;
    }
}

int findMovieTitle(const Movie topMovies[], const int SIZE, const string &title)
// This function receives the movies array, the size of the array, and the title
// of the movie to be searched for.
// It returns the index of the array where the title was found. If the title was 
// not found, it returns -1. It must use BINARY SEARCH to find the movie.
{
    int first = 0;
    int last  = SIZE - 1;
    int middle;
    int index   = -1;
    bool found = false;

    while (!found && first <= last)
    {
        middle = (first + last) / 2;

        if (topMovies[middle].title == title)
        {
            index = middle;
            found = true;
        }
        else if (topMovies[middle].title > title)
            last = middle - 1;
        else
            first = middle + 1;
    }

    return index;
}
